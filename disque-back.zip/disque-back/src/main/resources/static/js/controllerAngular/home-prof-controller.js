service.controller('homeProfissional', function homeProfissional($scope, $http) {
	
	console.log("controller do profissional");
	
});
