package br.com.beleza.Repository;

import org.springframework.data.repository.CrudRepository;

import br.com.beleza.model.FaleConosco;

public interface FaleConoscoRepository extends CrudRepository<FaleConosco, Integer>{

}
